/* Service worker: makes the birthday site work offline after the first visit */
const CACHE = "bday-v1";
const PRECACHE = [
 "./",
 "./apple-touch-icon.png",
 "./assets/music/birthday-song.mp3",
 "./assets/music/surprise.mp3",
 "./assets/photos/drawer.jpg",
 "./assets/photos/hero.jpg",
 "./assets/photos/photo1.jpg",
 "./assets/photos/photo10.jpg",
 "./assets/photos/photo2.jpg",
 "./assets/photos/photo3.jpg",
 "./assets/photos/photo4.jpg",
 "./assets/photos/photo5.jpg",
 "./assets/photos/photo6.jpg",
 "./assets/photos/photo7.jpg",
 "./assets/photos/photo8.jpg",
 "./assets/photos/photo9.jpg",
 "./assets/video/our-video.mp4",
 "./assets/video/our-video2.mp4",
 "./assets/video/our-video3.mp4",
 "./assets/video/our-video4.mp4",
 "./assets/video/poster.jpg",
 "./assets/video/poster2.jpg",
 "./assets/video/poster3.jpg",
 "./assets/video/poster4.jpg",
 "./icon-192.png",
 "./icon-512.png",
 "./icon-maskable-512.png",
 "./index.html",
 "./manifest.json",
 "./script.js",
 "./style.css"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((res) => {
      if (res && res.ok && new URL(e.request.url).origin === self.location.origin) {
        const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy));
      }
      return res;
    }).catch(() => caches.match("./index.html")))
  );
});
